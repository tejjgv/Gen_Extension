## 🚀 Quick Start

1. [Download the ZIP file](./assets/Gen_Extension.zip)  
2. Extract it to a folder  
3. Open `index.html` (or the main file) in your browser
